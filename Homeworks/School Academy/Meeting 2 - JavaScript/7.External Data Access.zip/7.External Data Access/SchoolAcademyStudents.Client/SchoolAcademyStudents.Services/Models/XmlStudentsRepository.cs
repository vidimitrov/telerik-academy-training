﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace SchoolAcademyStudents.Services.Models
{
    public class XmlStudentsRepository : IStudentsRepository
    {
        private readonly string filePathName;

        public XmlStudentsRepository()
        {
            var path = Path.GetTempPath() + "students.xml";
            if (!File.Exists(path))
            {
                XDocument doc = new XDocument();
                doc.Add(new XElement("students", new XAttribute("max-id", 0)));
                doc.Save(path);
            }
            this.filePathName = path;
        }

        public bool AddStudent(Student student)
        {
            XDocument doc = XDocument.Load(this.filePathName);
            var root = doc.Root;
            var maxId = int.Parse(root.Attribute("max-id").Value);
            root.SetAttributeValue("max-id", maxId + 1);

            root.Add(new XElement("student",
                new XAttribute("id", maxId),
                new XAttribute("firstname", student.Firstname),
                new XAttribute("lastname", student.Lastname),
                new XElement("marks",
                    (from mark in student.Marks
                     select new XElement("mark",
                         new XAttribute("subject", mark.Subject),
                         new XAttribute("score", mark.Score))))));
            doc.Save(this.filePathName);
            return true;
        }

        public IEnumerable<Student> GetStudents()
        {
            XDocument doc = XDocument.Load(this.filePathName);
            var root = doc.Root;

            var studentElemetns = root.Elements("student");

            List<Student> students = new List<Student>();
            foreach (var studentEl in studentElemetns)
            {
                var markElements = studentEl.Element("marks").Elements("mark");
                List<Mark> marks = new List<Mark>();
                foreach (var markEl in markElements)
                {
                    var subject = markEl.Attribute("subject").Value;
                    var score = markEl.Attribute("score").Value;
                    var mark = new Mark()
                    {
                        Subject = subject,
                        Score = score
                    };
                    marks.Add(mark);
                }

                var id = int.Parse(studentEl.Attribute("id").Value);
                var fname = studentEl.Attribute("firstname").Value;
                var lname = studentEl.Attribute("lastname").Value;
                var student = new Student()
                {
                    Id = id,
                    Firstname = fname,
                    Lastname = lname,
                    Marks = marks

                };
                students.Add(student);
            }
            return students;
        }

        public IEnumerable<Mark> GetStudentMarks(int studentId)
        {
            XDocument doc = XDocument.Load(this.filePathName);
            var root = doc.Root;
            var id = studentId.ToString();
            var student = root.Elements("student").FirstOrDefault(st => st.Attribute("id").Value == id);
            if (student == null)
            {
                return new List<Mark>();
            }
            var markElements = student.Element("marks").Elements("mark");
            List<Mark> marks = new List<Mark>();
            foreach (var markEl in markElements)
            {
                var subject = markEl.Attribute("subject").Value;
                var score = markEl.Attribute("score").Value;
                var mark = new Mark()
                {
                    Subject = subject,
                    Score = score
                };
                marks.Add(mark);
            }
            return marks;
        }
    }
}