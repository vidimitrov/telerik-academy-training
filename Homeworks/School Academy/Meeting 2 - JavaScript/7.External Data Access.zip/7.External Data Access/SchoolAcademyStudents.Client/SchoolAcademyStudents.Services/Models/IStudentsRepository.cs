﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAcademyStudents.Services.Models
{
    interface IStudentsRepository
    {
        bool AddStudent(Student student);
        IEnumerable<Student> GetStudents();
        IEnumerable<Mark> GetStudentMarks(int studentId);
    }
}