﻿using SchoolAcademyStudents.Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SchoolAcademyStudents.Services.Controllers
{
    public class StudentsController : ApiController
    {
        private readonly IStudentsRepository repository;

        public StudentsController()
        {
            this.repository = new XmlStudentsRepository();
        }

        /*
{
    "firstname" : "Doncho", 
    "lastname" : "Minkov",
    "marks" : [
        {"subject" : "Math","score" : 4.5},
        {"subject" : "Biology","score" : 3.5},
        {"subject" : "PHP","score" : 5.5}]
}
         */

        [ActionName("add")]
        public bool PostAddStudent(Student student)
        {
            var result = repository.AddStudent(student);
            return result;
        }

        [ActionName("all")]
        public IEnumerable<Student> GetStudents()
        {
            var students = repository.GetStudents();
            return students;
        }

        [ActionName("student-marks")]
        public IEnumerable<Mark> GetStudentMarks(int id)
        {
            var marks = repository.GetStudentMarks(id);
            return marks;
        }


    }
}