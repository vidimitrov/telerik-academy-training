﻿namespace NinjaFactory.ExcelReporting
{
    using NinjaFactory.DataBase.MySql;

    public class SuccessRateReport
    {
        public Ninja_catalogue_item NinjaCatalogueItem { get; set; }
    }
}
